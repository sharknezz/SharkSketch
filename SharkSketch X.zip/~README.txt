Instructions:
Extract all of the contents of this folder into the same location where the script will be run.

Run: SharkSketch2020.exe

Feedback: Report any bugs or comments to sharknezz / SJSpar7an.

Last updated: 5/12/2020
